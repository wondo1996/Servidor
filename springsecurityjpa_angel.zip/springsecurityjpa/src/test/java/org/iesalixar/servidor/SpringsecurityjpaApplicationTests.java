package org.iesalixar.servidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
