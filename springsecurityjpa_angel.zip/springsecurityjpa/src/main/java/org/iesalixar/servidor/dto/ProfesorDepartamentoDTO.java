package org.iesalixar.servidor.dto;

import java.io.Serializable;
import java.util.List;

import org.iesalixar.servidor.model.Departamento;
import org.iesalixar.servidor.model.Profesor;

public class ProfesorDepartamentoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Profesor> profesores;
	private List<Departamento> departamentos;
	
	public ProfesorDepartamentoDTO() {
		// TODO Auto-generated constructor stub
	}

	public List<Profesor> getProfesores() {
		return profesores;
	}

	public void setProfesores(List<Profesor> profesores) {
		this.profesores = profesores;
	}

	public List<Departamento> getDepartamentos() {
		return departamentos;
	}

	public void setDepartamentos(List<Departamento> departamentos) {
		this.departamentos = departamentos;
	}	

}
